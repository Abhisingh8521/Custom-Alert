package com.example.cotum_alert

import android.annotation.SuppressLint
import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val find = findViewById<Button>(R.id.btn11)
        find.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Enter Details.")

            val customLayout = layoutInflater.inflate(R.layout.coustum_layout, null)
            builder.setView(customLayout)

            builder.setPositiveButton("OK") {_,_ ->
                val Name = customLayout.findViewById<EditText>(R.id.name)
                val Password = customLayout.findViewById<EditText>(R.id.password)

                val ChangeStringName=(Name.text.toString())
                val ChangeStringPassword=(Password.text.toString())
                Toast.makeText(this, "Username:$ChangeStringName  Password: $ChangeStringPassword ", Toast.LENGTH_SHORT).show()

            }

            val dialog = builder.create()
            dialog.show()
        }
    }

    }


